﻿using ClosedXML.Excel;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Windows;

namespace StockQuatertlyAnalysis
{
    internal class ExcelRead
    {
        public DataTable previousQuarterData { get; set; }
        public DataTable currentQuarterData { get; set; }
        public DataTable industryData { get; set; }

        // Constructor to initialize the properties
        public ExcelRead()
        {
            previousQuarterData = new DataTable();
            currentQuarterData = new DataTable();
            industryData = new DataTable();
        }

        public string SelectExcelFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                previousQuarterData = ReadExcelFile(filePath);
                return openFileDialog.FileName;

            }
            return null;
        }

        public string SelectCurrentExcelFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                currentQuarterData = ReadExcelFile(filePath);
                return openFileDialog.FileName;

            }
            return null;
        }

        public string SelectIndustryExcelFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                industryData = ReadExcelFile(filePath);
                return openFileDialog.FileName;

            }
            return null;
        }
        public DataTable ReadExcelFile(string filePath)
        {
                    var dataTable = new DataTable();

                if (IsFileOpen(filePath))
                {
                MessageBox.Show("The Selecetd Excel file is currently open. Please close the file and try again.", "File Open");

            }
            else
                {
                using (var workbook = new XLWorkbook(filePath))
                {
                    var worksheet = workbook.Worksheet(1);
                    bool firstRow = true;
                    foreach (var row in worksheet.Rows())
                    {
                        if (firstRow)
                        {
                            foreach (var cell in row.Cells())
                            {
                                dataTable.Columns.Add(cell.Value.ToString());
                            }
                            firstRow = false;
                        }
                        else
                        {
                            dataTable.Rows.Add();
                            int i = 0;
                            foreach (var cell in row.Cells())
                            {
                                dataTable.Rows[dataTable.Rows.Count - 1][i] = cell.Value.ToString();
                                i++;
                            }
                        }
                    }
                }
                
            }
            return dataTable;

        }

        static bool IsFileOpen(string filePath)
        {
            try
            {
                using (FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    // If we can open the file with exclusive access, it's not open elsewhere
                    return false;
                }
            }
            catch (IOException)
            {
                // If an IOException is thrown, the file is likely open
                return true;
            }
        }

    }
}

