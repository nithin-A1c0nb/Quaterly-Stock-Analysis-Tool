﻿using Microsoft.Win32;
using System.Windows;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Controls;
using ClosedXML.Excel;
using System.Data;
using System.Windows.Media;



namespace StockQuatertlyAnalysis
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();   
        }


        ExcelRead excelRead = new ExcelRead();
        private void Till_Now_Button(object sender, RoutedEventArgs e)
        {
            string filePath = excelRead.SelectExcelFile();
            if (filePath != null)
            {
                FilePathTextBoxCurrent.Text = $"Previous Quarter File: {filePath}"; 
                ExcelDataGrid.ItemsSource = excelRead.previousQuarterData.DefaultView;
            }
        }

        private void Current_Quarter_Button(object sender, RoutedEventArgs e)
        { 
            string filePath = excelRead.SelectCurrentExcelFile();
            if (filePath != null)
            {
                FilePathTextBoxCurrent.Text = $"Current Quarter File: {filePath}";
                ExcelDataGrid.ItemsSource = excelRead.currentQuarterData.DefaultView;
            }
        }

        private void Analyze_Button(object sender, RoutedEventArgs e)
        {
            CompareExcelData compareExcelData = new CompareExcelData(excelRead.previousQuarterData, excelRead.currentQuarterData);
            //ExcelDataGrid.ItemsSource = compareExcelData.ReturnTable.DefaultView;
            this.Visibility = Visibility.Hidden;
            
            Window1 window1 = new Window1(compareExcelData.ReturnTable.DefaultView);
            window1.Show();
        }

        private void Industry_Excel_Button(object sender, RoutedEventArgs e)
        {
            string filePath = excelRead.SelectIndustryExcelFile();
            if (filePath != null)
            {
                FilePathTextBoxCurrent.Text = $"Industry Analysis: {filePath}";
                ExcelDataGrid.ItemsSource = excelRead.industryData.DefaultView;
                
            }
        }

    }
}