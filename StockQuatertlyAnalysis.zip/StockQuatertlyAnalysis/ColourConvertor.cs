﻿using DocumentFormat.OpenXml.Office2010.Word;
using System;
using System.Globalization;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using DocumentFormat.OpenXml.Drawing;
using System.Text.RegularExpressions;

namespace StockQuatertlyAnalysis
{
    public class ColourConvertor : IValueConverter
    {

        //(common == "PE" || common == "PB" || common == "DebtToEq" || common == "PEG" || common == "EVperEBITDA" || common == "CurrentRatio")
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            //string input = value;
            //string[] parts = input.Split(':');
            //string percentageString = parts[1].Trim();
            if (value is string stringValue && double.TryParse(stringValue, out double gValue))
            {
                //Check the condition
                if (gValue >= 10)
                {
                    if (gValue >= 10 && gValue < 20)
                    {
                        return Brushes.Orange;
                    }
                    else if (gValue >= 20 && gValue < 30)
                    {
                        
                        return Brushes.Red; 
                    }

                    else
                    {
                        
                        return Brushes.DarkRed;
                    }
                }
                else {
                    if (gValue > 0 && gValue < 10)
                    {
                        return Brushes.Blue;
                    }

                    else if (gValue <= 0 && gValue >= -10)
                    {
                        return Brushes.LightGreen;
                    }
                    else
                    {
                        return Brushes.DarkGreen;
                    }
                }
            }
                return Brushes.Black;  // Default color
            
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class ColorConvertor : IValueConverter
    {

        //Rest of values
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string stringValue && double.TryParse(stringValue, out double gValue))
            {
                //Check the condition
                if (gValue >= 10)
                {
                    if (gValue >= 10 && gValue < 20)
                    {
                        return Brushes.LightGreen;
                    }
                    else if (gValue >= 20 && gValue < 30)
                    {
                        return Brushes.Green;
                    }

                    else
                    {
                        return Brushes.DarkGreen;
                    }
                }
                else
                {
                    if (gValue < 10 && gValue > 0)
                    {
                        return Brushes.Blue;
                    }

                    else if (gValue <= 0 && gValue >= -10)
                    {
                        return Brushes.Orange;
                    }
                    else
                    {
                        return Brushes.Red;
                    }
                }
            }
            return Brushes.Black;  // Default color

        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }


    }

    public class BoldConvertor : IValueConverter
    {

        //(common == "PE" || common == "PB" || common == "DebtToEq" || common == "PEG" || common == "EVperEBITDA" || common == "CurrentRatio")
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            if (value is string stringValue && double.TryParse(stringValue, out double gValue))
            {
                //Check the condition
                if (gValue >= 10)
                {
                    if (gValue >= 10 && gValue < 20)
                    {
                        return FontWeights.Normal;
                    }
                    else if (gValue >= 20 && gValue < 30)
                    {

                        return FontWeights.Bold;
                    }

                    else
                    {

                        return FontWeights.Bold;
                    }
                }
                else
                {
                    if (gValue > 0 && gValue < 10)
                    {
                        return FontWeights.Normal;
                    }

                    else if (gValue <= 0 && gValue >= -10)
                    {
                        return FontWeights.Normal;
                    }
                    else
                    {
                        return FontWeights.Bold;
                    }
                }
            }
            return FontWeights.Normal;  // Default color

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class Bold1Convertor : IValueConverter
    {

        //Rest of values
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is string stringValue && double.TryParse(stringValue, out double gValue))
            {
                //Check the condition
                if (gValue >= 10)
                {
                    if (gValue >= 10 && gValue < 20)
                    {
                        return FontWeights.Normal;
                    }
                    else if (gValue >= 20 && gValue < 30)
                    {
                        return FontWeights.Normal;
                    }

                    else
                    {
                        return FontWeights.Bold;
                    }
                }
                else
                {
                    if (gValue < 10 && gValue > 0)
                    {
                        return FontWeights.Normal;
                    }
                    else if (gValue <= 0 && gValue >= -10)
                    {
                        return FontWeights.Normal;
                    }
                    else
                    {
                        return FontWeights.Bold;
                    }
                }
            }
            return FontWeights.Normal;  // Default color

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
