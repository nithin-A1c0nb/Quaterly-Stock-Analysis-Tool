﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using ClosedXML.Excel;
using System.Data;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Math;
using System.Reflection.Emit;
using System.Windows;
using System.Text.RegularExpressions;
using System.Collections.Immutable;
using System.Media;
using static System.Windows.Forms;
using System.Windows.Controls;
using System.Windows.Media;
using colours = System.Windows.Media;



namespace StockQuatertlyAnalysis
{
    internal class CompareExcelData : MainWindow
    {

        private DataTable PreviousQuarter { get; set; }
        private DataTable CurrentQuarter { get; set; }
        public DataTable ReturnTable { get; set; }

        public string TextColor { get; set; }

        private string test;

        public CompareExcelData(DataTable previousQuater, DataTable currentQuater)
        {
            PreviousQuarter = previousQuater;
            CurrentQuarter = currentQuater;
            ReturnTable = CompareData();
        }
        public DataTable CompareData()
        {

            // Create a new DataTable
            DataTable newDataTable = new DataTable();
            foreach (DataColumn column in CurrentQuarter.Columns)
            {
                newDataTable.Columns.Add(column.ColumnName, column.DataType);
            }

            // Copy the entire columns from the Current Quarter to the new DataTable
            foreach (DataRow row in CurrentQuarter.Rows)
            {
                DataRow newRow = newDataTable.NewRow();
                TextBlock textBlock = new TextBlock();
                newRow["SNo"] = row["SNo"];
                newRow["Name"] = row["Name"];
                newRow["MarCap"] = row["MarCap"];
                // Call the CMP method and assign the result to the new row
                string cmpValue = row["CMP"].ToString();
                string previousCmpValue = GetPreviousCmpValue(row["Name"].ToString());
                // Method to get the previous excel values
                newRow["CMP"] = CMP(cmpValue, previousCmpValue);
                string[] columnsToProcess = { "PE", "PB", "ROCE", "ROE", "DebtToEq", "PEG", "EVperEBITDA", "CurrentRatio", "SalesGrowth", "ProfitGrowth", "QtrSalesVar", "QtrProfitVar", "OneYrReturn", "OPM" };
                string currentValue = "";
                string previousValue = "";
                //string  strCellColorStr, colourResult;
                double cellValWithHash;
                //Color color = new Color();
                foreach (string column in columnsToProcess)
                {
                    currentValue = row[column].ToString();
                    previousValue = GetPreviousValue(row["Name"].ToString(), column);
                    cellValWithHash = Common_Values(currentValue, previousValue, column);
                    /*
                    textBlock.Text = cellValWithHash.Replace("%Red", ""); // "EntireString #Red"
                    colourResult = Regex.Match(cellValWithHash, @"\bRed\b").Value;
                    
                    if (colourResult == "Red")
                    {
                        textBlock.Foreground = new SolidColorBrush(colours.Colors.Green);
                        newRow[column] = textBlock.Text;
                    }
                    else
                    {
                        textBlock.Foreground = new SolidColorBrush(colours.Colors.Green);
                        newRow[column] = textBlock.Text;
                    }
                    */

                    newRow[column] = cellValWithHash;

                }

                newDataTable.Rows.Add(newRow);
            }

            return newDataTable;
        }


        private string CMP(string currentCMPvalue, string previousCMPvalue)
        {

            // Try to parse the input strings to doubles
            if (double.TryParse(currentCMPvalue, out double doublecurrentCMPvalue) && double.TryParse(previousCMPvalue, out double doublepreviousCMPvalue))
            {
                double returnValue = doublecurrentCMPvalue - doublepreviousCMPvalue;
                double percentageIncrease = 100 - ((doublecurrentCMPvalue / doublepreviousCMPvalue) * 100);
                returnValue = Math.Round(returnValue, 2);
                percentageIncrease = Math.Round(percentageIncrease, 2);
                if (returnValue < 0)
                {
                    return ($"Value Fall: {returnValue} \nPercentage down: {percentageIncrease}");
                }
                else
                {
                    return ($"Value up: {returnValue} \nPercentage up: {percentageIncrease}");
                }


            }

            else
            {
                //error handling
                return "Invalid input";
            }
        }
        private string GetPreviousCmpValue(string name)
        {
            // Logic to get the previous CMP value based on the company name
            DataRow[] previousRows = PreviousQuarter.Select($"Name = '{name}'");
            if (previousRows.Length > 0)
            {
                return previousRows[0]["CMP"].ToString();
            }
            return null;
        }

        private string GetPreviousValue(string name, string common)
        {
            // Logic to get all the previous value based on the company name
            DataRow[] previousRows = PreviousQuarter.Select($"Name = '{name}'");
            if (previousRows.Length > 0)
            {
                return previousRows[0][common].ToString();
            }
            return null;
        }
        private double Common_Values(string currentvalue, string previousvalue, string common)
        {

            // Try to parse the input strings to doubles
            if (double.TryParse(currentvalue, out double doublecurrentvalue) && double.TryParse(previousvalue, out double doublepreviousvalue))
            {
                double returnValue = doublecurrentvalue - doublepreviousvalue;
                double percentageIncrease;
                if (doublecurrentvalue >= doublepreviousvalue)
                {
                    percentageIncrease = Math.Abs(100 - ((doublecurrentvalue / doublepreviousvalue) * 100));
                }
                else
                {
                    percentageIncrease = ((doublecurrentvalue / doublepreviousvalue) * 100) - 100;
                }
                returnValue = Math.Round(returnValue, 2);
                percentageIncrease = Math.Round(percentageIncrease, 2);
                return (percentageIncrease);
                    /*
                    if (returnValue <= 0)
                    {
                        if (common == "PE" || common == "PB" || common == "DebtToEq" || common == "PEG" || common == "EVperEBITDA" || common == "CurrentRatio")
                        {


                            //return ($"Current {common}: {doublecurrentvalue}     Previous {common}: {doublepreviousvalue} \nPercentage down: {percentageIncrease}");
                            return ($"Current {common}: {doublecurrentvalue}     Previous {common}: {doublepreviousvalue} \nPercentage down: {percentageIncrease}");

                        }
                        else
                        {
                            // Console.ForegroundColor = ConsoleColor.Red;
                            return ($"Current {common}: {doublecurrentvalue}     Previous {common}: {doublepreviousvalue} \nPercentage down: {percentageIncrease}");

                        }


                    }
                    else
                    {
                        if (common == "PE" || common == "PB" || common == "DebtToEq" || common == "PEG" || common == "EVperEBITDA" || common == "CurrentRatio")
                        {
                            //Console.ForegroundColor = ConsoleColor.Red;
                            return ($"Current {common}: {doublecurrentvalue}     Previous {common}: {doublepreviousvalue} \nPercentage up: {percentageIncrease}");
                        }
                        else
                        {
                            // Console.ForegroundColor = ConsoleColor.Green;
                            return ($"Current {common}: {doublecurrentvalue}     Previous {common}: {doublepreviousvalue} \nPercentage up: {percentageIncrease}");
                        }
                    }
                    */

                }
    
            else
                {
                    // Handle the case where parsing fails (e.g., return an error message or a default value)
                    return 0001;
                }
            }


        }

    }


